export default function Accueil() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-xl flex-col px-5 py-8">
      <p className="text-sm font-bold uppercase tracking-widest text-braise">
        Fantômes
      </p>

      <section className="mt-10">
        <h1 className="font-titre text-4xl font-extrabold leading-tight sm:text-5xl">
          Ces abonnements que tu paies sans t&rsquo;en servir ? On les débusque.
        </h1>
        <p className="mt-5 text-lg leading-relaxed">
          Un essai jamais résilié, un service remplacé, une option activée une
          fois. Petits prélèvements, grosse addition : un abonnement oublié à
          9,99&nbsp;€ par mois, c&rsquo;est <strong>120&nbsp;€ par an</strong>.
        </p>

        <a
          href="#ouverture"
          className="mt-8 flex h-14 w-full items-center justify-center rounded-xl bg-braise text-lg font-bold text-white active:opacity-90"
        >
          Commencer, c&rsquo;est gratuit
        </a>
      </section>

      <section className="mt-12">
        <ul className="space-y-5">
          <li>
            <h2 className="font-titre text-xl font-semibold">
              Tu déposes ton relevé
            </h2>
            <p className="mt-1">
              Il est lu sur ton téléphone et ne quitte jamais ton appareil.
            </p>
          </li>
          <li>
            <h2 className="font-titre text-xl font-semibold">
              Tu vois tes fantômes, du plus cher au moins cher
            </h2>
            <p className="mt-1">
              Classés par coût annuel, pour savoir par lequel commencer.
            </p>
          </li>
          <li>
            <h2 className="font-titre text-xl font-semibold">
              Tu résilies en un clic de copier-coller
            </h2>
            <p className="mt-1">Une lettre de résiliation prête pour chacun.</p>
          </li>
        </ul>
      </section>

      <section
        id="ouverture"
        className="mt-12 rounded-xl border-2 border-encre p-5"
      >
        <h2 className="font-titre text-xl font-semibold">
          Ouverture très bientôt
        </h2>
        <p className="mt-2">
          Le produit est en construction. Cette page est la première pierre.
        </p>
      </section>

      <footer className="mt-auto pt-12 text-sm opacity-70">
        © Fantômes. Mentions légales à venir.
      </footer>
    </main>
  );
}
