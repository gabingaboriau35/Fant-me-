import type { Metadata, Viewport } from "next";
import { Fraunces, DM_Sans } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  weight: ["600", "800"],
  variable: "--font-fraunces",
  display: "swap",
});

const dm = DM_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-dm",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Fantômes — Débusque les abonnements que tu paies sans t'en servir",
  description:
    "Dépose ton relevé bancaire : Fantômes repère les prélèvements oubliés et prépare les lettres de résiliation. Ton relevé ne quitte pas ton téléphone.",
  openGraph: {
    title: "Fantômes — Débusque les abonnements que tu paies sans t'en servir",
    description:
      "Dépose ton relevé bancaire et vois combien te coûtent tes abonnements oubliés.",
    locale: "fr_FR",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#f6f1e7",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className={`${fraunces.variable} ${dm.variable}`}>
      <body className="min-h-dvh antialiased">{children}</body>
    </html>
  );
}
